// ===== Mobile Nav Toggle =====
const menuToggle = document.getElementById('menuToggle');
const navLinks = document.getElementById('navLinks');

menuToggle.addEventListener('click', () => {
  navLinks.classList.toggle('open');
});

// Close mobile menu when a link is clicked
navLinks.querySelectorAll('a').forEach(link => {
  link.addEventListener('click', () => navLinks.classList.remove('open'));
});


// ===== To-Do List (Dynamic DOM Manipulation) =====
const todoInput = document.getElementById('todoInput');
const addTodoBtn = document.getElementById('addTodoBtn');
const todoList = document.getElementById('todoList');
const todoError = document.getElementById('todoError');
const todoSummary = document.getElementById('todoSummary');

let tasks = []; // { id, text, completed }
let taskIdCounter = 0;

function addTask() {
  const value = todoInput.value.trim();

  if (value === '') {
    todoError.textContent = 'Please type a task before adding it.';
    return;
  }

  todoError.textContent = '';

  tasks.push({ id: taskIdCounter++, text: value, completed: false });
  todoInput.value = '';
  todoInput.focus();
  renderTasks();
}

function renderTasks() {
  todoList.innerHTML = ''; // clear and rebuild list from current state

  if (tasks.length === 0) {
    todoSummary.textContent = 'No tasks yet — add one above to get started.';
    return;
  }

  tasks.forEach(task => {
    const li = document.createElement('li');

    const span = document.createElement('span');
    span.textContent = task.text;
    span.className = 'todo-text' + (task.completed ? ' completed' : '');
    span.addEventListener('click', () => toggleComplete(task.id));

    const deleteBtn = document.createElement('button');
    deleteBtn.textContent = '✕';
    deleteBtn.className = 'todo-delete';
    deleteBtn.setAttribute('aria-label', 'Delete task');
    deleteBtn.addEventListener('click', () => deleteTask(task.id));

    li.appendChild(span);
    li.appendChild(deleteBtn);
    todoList.appendChild(li);
  });

  const completedCount = tasks.filter(t => t.completed).length;
  todoSummary.textContent = `${completedCount} of ${tasks.length} task(s) completed`;
}

function toggleComplete(id) {
  tasks = tasks.map(t => t.id === id ? { ...t, completed: !t.completed } : t);
  renderTasks();
}

function deleteTask(id) {
  tasks = tasks.filter(t => t.id !== id);
  renderTasks();
}

addTodoBtn.addEventListener('click', addTask);
todoInput.addEventListener('keypress', (e) => {
  if (e.key === 'Enter') addTask();
});


// ===== Contact Form Validation =====
const contactForm = document.getElementById('contactForm');
const nameInput = document.getElementById('name');
const emailInput = document.getElementById('email');
const messageInput = document.getElementById('message');

const nameError = document.getElementById('nameError');
const emailError = document.getElementById('emailError');
const messageError = document.getElementById('messageError');
const formSuccess = document.getElementById('formSuccess');

function isValidEmail(value) {
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  return emailPattern.test(value);
}

function showError(input, errorEl, message) {
  input.classList.add('invalid');
  errorEl.textContent = message;
}

function clearError(input, errorEl) {
  input.classList.remove('invalid');
  errorEl.textContent = '';
}

contactForm.addEventListener('submit', function (e) {
  e.preventDefault();
  formSuccess.textContent = '';

  let isValid = true;

  // Name validation
  if (nameInput.value.trim() === '') {
    showError(nameInput, nameError, 'Name is required.');
    isValid = false;
  } else {
    clearError(nameInput, nameError);
  }

  // Email validation
  if (emailInput.value.trim() === '') {
    showError(emailInput, emailError, 'Email is required.');
    isValid = false;
  } else if (!isValidEmail(emailInput.value.trim())) {
    showError(emailInput, emailError, 'Please enter a valid email address.');
    isValid = false;
  } else {
    clearError(emailInput, emailError);
  }

  // Message validation
  if (messageInput.value.trim() === '') {
    showError(messageInput, messageError, 'Message cannot be empty.');
    isValid = false;
  } else {
    clearError(messageInput, messageError);
  }

  if (isValid) {
    formSuccess.textContent = "Thanks! Your message has been received.";
    contactForm.reset();
  }
});
